# Deploying RESPONSE to Vercel

Static site — no build step.

1. Push this folder to GitHub (RBSTALLION/RESPONSE), or run `npx vercel` in it.
2. In Vercel: New Project → import the repo → Framework preset **Other**, Build command empty, Output directory `.` → Deploy.
3. Routes (from vercel.json):
   - `/`        → design frames (phone + laptop, shared live state)
   - `/app`     → officer app (installable PWA; service worker + manifest live in /app)
   - `/portal`  → control room

Notes
- The AI "Tidy into a formal report" button uses window.claude.complete, which exists only inside the design host. On Vercel it shows "AI not available" — swap in a serverless function (`/api/tidy`) that calls the Anthropic API when you're ready.
- State is browser-local (localStorage + BroadcastChannel). Two tabs on one device sync; two devices don't — that's what db/schema.sql is for.
- Add to Home Screen on iPhone: open /app in Safari → Share → Add to Home Screen.
